function Util(){    
    this.backgroundImg=new Image();
    this.backgroundImg.src="media/background.png";
    this.backgroundX=0;
    this.backgroundY=0;
    
    this.descargaImg=new Image();
    this.descargaImg.src="media/descarga1.png";
    this.descargaX=290;
    this.descargaY=10;
    this.descarga=0;
    
    this.tiempoImg=new Image();
    this.tiempoImg.src="media/59.png";
    this.tiempoX=840;
    this.tiempoY=30;
    
    this.senalImg=new Image();
    this.senalImg.src="media/red.png";
    this.senalX=20;
    this.senalY=20;
    this.senalIntensidad=10;
    
    this.antenaImg=new Image();
    this.antenaImg.src="media/antena.png";
    this.antenaX=450;
    this.antenaY=66;
    
    this.senalImg1=new Image();
    this.senalImg1.src="media/red.png";
    
    this.senalImg2=new Image();
    this.senalImg2.src="media/red1.png";
    
    this.senalImg3=new Image();
    this.senalImg3.src="media/red2.png";
    
    this.senalImg4=new Image();
    this.senalImg4.src="media/red3.png";
    
    this.senalImg5=new Image();
    this.senalImg5.src="media/red4.png";
    
    this.senalImg6=new Image();
    this.senalImg6.src="media/red5.png";
    
    this.senalImg7=new Image();
    this.senalImg7.src="media/red6.png";
    
    this.senalImg8=new Image();
    this.senalImg8.src="media/red7.png";
    
    this.senalImg9=new Image();
    this.senalImg9.src="media/red8.png";
    
    
    this.descargaImg1=new Image();
    this.descargaImg1.src="media/descarga1.png";
    
    this.descargaImg2=new Image();
    this.descargaImg2.src="media/descarga2.png";
    
    this.descargaImg3=new Image();
    this.descargaImg3.src="media/descarga3.png";
    
    this.descargaImg4=new Image();
    this.descargaImg4.src="media/descarga4.png";
    
    this.descargaImg5=new Image();
    this.descargaImg5.src="media/descarga5.png";
    
    this.descargaImg6=new Image();
    this.descargaImg6.src="media/descarga6.png";
    
    this.descargaImg7=new Image();
    this.descargaImg7.src="media/descarga7.png";
    
    this.descargaImg8=new Image();
    this.descargaImg8.src="media/descarga8.png";
    
    this.descargaImg9=new Image();
    this.descargaImg9.src="media/descarga9.png";
    
    this.descargaImg10=new Image();
    this.descargaImg10.src="media/descarga10.png";
    
    this.descargaImg11=new Image();
    this.descargaImg11.src="media/descarga11.png";
    
    
    this.tiempoImg59=new Image();
    this.tiempoImg59.src="media/59.png";
    this.tiempoImg58=new Image();
    this.tiempoImg58.src="media/58.png";
    this.tiempoImg57=new Image();
    this.tiempoImg57.src="media/57.png";
    this.tiempoImg56=new Image();
    this.tiempoImg56.src="media/56.png";
    
    this.tiempoImg55=new Image();
    this.tiempoImg55.src="media/55.png";
    this.tiempoImg54=new Image();
    this.tiempoImg54.src="media/54.png";
    this.tiempoImg53=new Image();
    this.tiempoImg53.src="media/53.png";
    this.tiempoImg52=new Image();
    this.tiempoImg52.src="media/52.png";
    this.tiempoImg51=new Image();
    this.tiempoImg51.src="media/51.png";
    
    this.tiempoImg50=new Image();
    this.tiempoImg50.src="media/50.png";
    this.tiempoImg49=new Image();
    this.tiempoImg49.src="media/49.png";
    this.tiempoImg48=new Image();
    this.tiempoImg48.src="media/48.png";
    this.tiempoImg47=new Image();
    this.tiempoImg47.src="media/47.png";
    this.tiempoImg46=new Image();
    this.tiempoImg46.src="media/46.png";
    
    this.tiempoImg45=new Image();
    this.tiempoImg45.src="media/45.png";
    this.tiempoImg44=new Image();
    this.tiempoImg44.src="media/44.png";
    this.tiempoImg43=new Image();
    this.tiempoImg43.src="media/43.png";
    this.tiempoImg42=new Image();
    this.tiempoImg42.src="media/42.png";
    this.tiempoImg41=new Image();
    this.tiempoImg41.src="media/41.png";
    
    this.tiempoImg40=new Image();
    this.tiempoImg40.src="media/40.png";
    this.tiempoImg39=new Image();
    this.tiempoImg39.src="media/39.png";
    this.tiempoImg38=new Image();
    this.tiempoImg38.src="media/38.png";
    this.tiempoImg37=new Image();
    this.tiempoImg37.src="media/37.png";
    this.tiempoImg36=new Image();
    this.tiempoImg36.src="media/36.png";
   
    this.tiempoImg35=new Image();
    this.tiempoImg35.src="media/35.png";
    this.tiempoImg34=new Image();
    this.tiempoImg34.src="media/34.png";
    this.tiempoImg33=new Image();
    this.tiempoImg33.src="media/33.png";
    this.tiempoImg32=new Image();
    this.tiempoImg32.src="media/32.png";
    this.tiempoImg31=new Image();
    this.tiempoImg31.src="media/31.png";
    
    this.tiempoImg30=new Image();
    this.tiempoImg30.src="media/30.png";
    this.tiempoImg29=new Image();
    this.tiempoImg29.src="media/29.png";
    this.tiempoImg28=new Image();
    this.tiempoImg28.src="media/28.png";
    this.tiempoImg27=new Image();
    this.tiempoImg27.src="media/27.png";
    this.tiempoImg26=new Image();
    this.tiempoImg26.src="media/26.png";
    
    this.tiempoImg25=new Image();
    this.tiempoImg25.src="media/25.png";
    this.tiempoImg24=new Image();
    this.tiempoImg24.src="media/24.png";
    this.tiempoImg23=new Image();
    this.tiempoImg23.src="media/23.png";
    this.tiempoImg22=new Image();
    this.tiempoImg22.src="media/22.png";
    this.tiempoImg21=new Image();
    this.tiempoImg21.src="media/21.png";
    
    this.tiempoImg20=new Image();
    this.tiempoImg20.src="media/20.png";
    this.tiempoImg19=new Image();
    this.tiempoImg19.src="media/19.png";
    this.tiempoImg18=new Image();
    this.tiempoImg18.src="media/18.png";
    this.tiempoImg17=new Image();
    this.tiempoImg17.src="media/17.png";
    this.tiempoImg16=new Image();
    this.tiempoImg16.src="media/16.png";
    
    this.tiempoImg15=new Image();
    this.tiempoImg15.src="media/15.png";
    this.tiempoImg14=new Image();
    this.tiempoImg14.src="media/14.png";
    this.tiempoImg13=new Image();
    this.tiempoImg13.src="media/13.png";
    this.tiempoImg12=new Image();
    this.tiempoImg12.src="media/12.png";
    this.tiempoImg11=new Image();
    this.tiempoImg11.src="media/11.png";
    
    this.tiempoImg10=new Image();
    this.tiempoImg10.src="media/10.png";
    this.tiempoImg9=new Image();
    this.tiempoImg9.src="media/9.png";
    this.tiempoImg8=new Image();
    this.tiempoImg8.src="media/8.png";
    this.tiempoImg7=new Image();
    this.tiempoImg7.src="media/7.png";
    this.tiempoImg6=new Image();
    this.tiempoImg6.src="media/6.png";
    
    this.tiempoImg5=new Image();
    this.tiempoImg5.src="media/5.png";
    this.tiempoImg4=new Image();
    this.tiempoImg4.src="media/4.png";
    this.tiempoImg3=new Image();
    this.tiempoImg3.src="media/3.png";
    this.tiempoImg2=new Image();
    this.tiempoImg2.src="media/2.png";
    this.tiempoImg1=new Image();
    this.tiempoImg1.src="media/1.png";
    
}

        
