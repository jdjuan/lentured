function Enemigo(){    
    this.img=new Image();
    this.img.src="media/concerje.png";
    this.x=0;
    this.y=0;
    this.activo=false;
}