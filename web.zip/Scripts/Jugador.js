function Jugador(){    
    this.x=450;
    this.y=510;
    this.indexSprite=0;
    this.direccionDer=false;
    this.direccionIzq=false;
    
    this.imgIzq=new Image();
    this.imgIzq.src="media/avatarIzq.png";    
    
    this.imgDer=new Image();
    this.imgDer.src="media/avatarDer.png";    
    
    this.img=new Image();
    this.img.src="media/avatarDer.png";    

    
}

        
        
