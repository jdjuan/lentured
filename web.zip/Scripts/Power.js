function Power(){    
    this.senal=new Image();
    this.senalX=0;
    this.senalY=0;
//    this.img.src="media/avatar0.png";    
}

        
