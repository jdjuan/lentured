function Senal(){    
    this.img=new Image();
    this.img.src="media/senal.png";
    this.tipo=0;
    this.x=0;
    this.y=0;
    this.activa=true;
    
}